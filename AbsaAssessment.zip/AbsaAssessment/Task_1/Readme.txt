Resources Used
	Soapui- for verifying and validating manually if the endpoints provided are returning the correct responses as per task
	Intellij IDEA- used this IDEA for automating all the tasks( used Java code for task 1 and intergrated java code with selenium web driver for
	 task 2)
	JDK
	

The following below is how the project has been completed

Task 1:

use the bellow path to run task1-
...\AbsaAssessment\Task_1\src\test\java\Task1\GetallDogs.java
-in this class, you will get all the results of task 1.

Task 2:
use the below path for task 2-
...\AbsaAssessment\Task_1\src\test\java\Task2\TestRunnerTest.java

this will add all the required users